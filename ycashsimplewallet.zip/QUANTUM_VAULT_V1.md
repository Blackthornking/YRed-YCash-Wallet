# Quantum Vault — V1

## Purpose
Protect wallet seed material and other high-value secrets at rest without changing
Ycash transaction or signature serialization.

## Protection design
- Primary authenticated encryption: AES-256-GCM.
- A unique random 96-bit nonce is generated for every encryption operation.
- The encryption key is derived from a high-entropy vault secret using HKDF-SHA-256.
- The vault secret must come from a cryptographically secure random source; it is not
  derived from a 64-bit deterministic seed.
- Optional platform authentication (PIN/biometric) unlocks access to the vault key;
  biometrics are an unlock factor, not the cryptographic key itself.
- Failed unlock attempts should be rate-limited by the platform secure storage layer.
- Plaintext seed material should be kept in memory for the shortest practical time.

## Post-quantum / hybrid note
AES-256-GCM remains the symmetric confidentiality layer. If a post-quantum key
encapsulation mechanism is used for wrapping a vault key, use a NIST-standardized
ML-KEM profile and a versioned hybrid envelope. The wallet's existing transaction,
address, and 1140-byte signature formats remain unchanged.

## Versioning
Vault records carry an explicit version and algorithm identifier so future migration
can occur without ambiguity. Existing wallet transaction/signature formats are not
modified by the vault layer.

## Serialization
The vault container is separate from blockchain transaction/signature serialization.
Adding this vault therefore does not change the 1140-byte signature invariant or
verification behavior.
