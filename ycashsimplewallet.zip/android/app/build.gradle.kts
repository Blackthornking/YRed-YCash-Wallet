import java.io.FileInputStream
import java.util.Properties

val keystoreProperties = Properties()
val keystorePropertiesFile = rootProject.file("key.properties")
if (keystorePropertiesFile.exists()) {
    FileInputStream(keystorePropertiesFile).use { keystoreProperties.load(it) }
}

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("dev.flutter.flutter-gradle-plugin")
}

android {
    namespace = "com.ycashfoundation.ycashsimple"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    defaultConfig {
        applicationId = "com.ycashfoundation.ycashsimple"
        minSdk = 26
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    signingConfigs {
        if (keystorePropertiesFile.exists()) {
            create("release") {
                keyAlias = keystoreProperties.getProperty("keyAlias")
                keyPassword = keystoreProperties.getProperty("keyPassword")
                storeFile = file(keystoreProperties.getProperty("storeFile"))
                storePassword = keystoreProperties.getProperty("storePassword")
            }
        }
    }

    buildTypes {
        getByName("release") {
            if (keystorePropertiesFile.exists()) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }
}

flutter {
    source = "../.."
}



val ycashCoreRustDir = rootProject.file("../packages/ycash_core_ffi/rust")
val rustJniDir = project.file("src/main/jniLibs")
val rustAbis = listOf("arm64-v8a", "armeabi-v7a", "x86_64")

fun androidCargoCommand(features: String = ""): String {
    val featureArg = if (features.isBlank()) "" else " --features $features"
    return "command -v cargo >/dev/null || { echo 'Rust cargo is required'; exit 1; }; " +
        "command -v cargo-ndk >/dev/null || { echo 'cargo-ndk is required'; exit 1; }; " +
        "cargo ndk -t arm64-v8a -t armeabi-v7a -t x86_64 -o " +
        "'${rustJniDir.absolutePath}' build --release$featureArg"
}

val buildYcashCoreNative by tasks.registering(Exec::class) {
    group = "build"
    description = "Builds libycash_core.so for Android ABIs."
    workingDir = ycashCoreRustDir
    doFirst {
        check(ycashCoreRustDir.isDirectory) { "Ycash core Rust source missing: ${ycashCoreRustDir.absolutePath}" }
        rustJniDir.mkdirs()
    }
    commandLine("bash", "-lc", androidCargoCommand())
}

val verifyNativeLibraries by tasks.registering {
    dependsOn(buildYcashCoreNative)
    doLast {
        rustAbis.forEach { abi ->
            val lib = "libycash_core.so"
            val output = File(rustJniDir, "$abi/$lib")
            check(output.isFile && output.length() > 0L) {
                "Native build completed but did not produce ${output.absolutePath}"
            }
        }
    }
}

tasks.matching { it.name == "preBuild" }.configureEach {
    dependsOn(verifyNativeLibraries)
}
