# AWBS V11 — Bridge/Skip Infrastructure

Implemented a fail-closed Warp Sync 2-style bridge layer.

- Added a durable `awbs_bridges.json` bridge cache.
- Bridges are range-bound and SHA-256 authenticated against their exact
  start/end heights, roots, and payload.
- Added `BridgeStore` and `choose_range_mode()` for safe normal-vs-bridge
  selection.
- A bridge is eligible only when the range contains no newly received wallet
  notes and an authenticated bridge exactly covers that range.
- Any missing, malformed, stale, or tampered bridge falls back to the existing
  normal scanner; no wallet state is skipped.
- The existing ordered wallet/tree commit path is unchanged.

## Important compatibility note

The Ycash lightwalletd endpoint currently used by AWBS does not expose the
private WarpSync-2 `get bridge` API. Therefore V11 includes the complete
bridge cache/validation and selection layer, but does **not** fabricate bridge
payloads or claim bridge acceleration is active against the existing server.
A compatible bridge endpoint can populate the cache later without changing
wallet serialization or verification behaviour.
