library ycash_core;

import 'dart:convert';
import 'dart:ffi';
import 'dart:io';

import 'package:ffi/ffi.dart';

class YcashCoreException implements Exception {
  final String message;
  const YcashCoreException(this.message);
  @override
  String toString() => 'YcashCoreException: $message';
}

class YcashCoreNative {
  YcashCoreNative._(this._lib);

  final DynamicLibrary _lib;

  static final YcashCoreNative instance = YcashCoreNative._(_openLibrary());

  static DynamicLibrary _openLibrary() {
    if (Platform.isAndroid) return DynamicLibrary.open('libycash_core.so');
    if (Platform.isLinux) return DynamicLibrary.open('libycash_core.so');
    if (Platform.isMacOS) return DynamicLibrary.open('libycash_core.dylib');
    if (Platform.isWindows) return DynamicLibrary.open('ycash_core.dll');
    throw UnsupportedError('Ycash native engine is not available on this platform');
  }

  late final _free = _lib.lookupFunction<
      Void Function(Pointer<Utf8>), void Function(Pointer<Utf8>)>('ycash_string_free');

  late final _yecFree = _lib.lookupFunction<
      Void Function(Pointer<Utf8>), void Function(Pointer<Utf8>)>('ycash_yecshell_string_free');

  late final _generateMnemonic = _lib.lookupFunction<
      Pointer<Utf8> Function(Pointer<Pointer<Utf8>>),
      Pointer<Utf8> Function(Pointer<Pointer<Utf8>>)>(
    'ycash_yecshell_generate_mnemonic',
  );

  late final _configure = _lib.lookupFunction<
      Uint8 Function(Pointer<Utf8>, Pointer<Utf8>, Pointer<Pointer<Utf8>>),
      int Function(Pointer<Utf8>, Pointer<Utf8>, Pointer<Pointer<Utf8>>)>(
    'ycash_yecshell_configure',
  );

  late final _open = _lib.lookupFunction<
      Uint8 Function(Pointer<Utf8>, Uint64, Pointer<Pointer<Utf8>>),
      int Function(Pointer<Utf8>, int, Pointer<Pointer<Utf8>>)>(
    'ycash_yecshell_open',
  );

  late final _addresses = _lib.lookupFunction<
      Pointer<Utf8> Function(Pointer<Pointer<Utf8>>),
      Pointer<Utf8> Function(Pointer<Pointer<Utf8>>)>(
    'ycash_yecshell_addresses',
  );

  late final _balances = _lib.lookupFunction<
      Pointer<Utf8> Function(Pointer<Pointer<Utf8>>),
      Pointer<Utf8> Function(Pointer<Pointer<Utf8>>)>(
    'ycash_yecshell_balances',
  );

  late final _history = _lib.lookupFunction<
      Pointer<Utf8> Function(Pointer<Pointer<Utf8>>),
      Pointer<Utf8> Function(Pointer<Pointer<Utf8>>)>(
    'ycash_yecshell_history',
  );

  late final _notes = _lib.lookupFunction<
      Pointer<Utf8> Function(Pointer<Pointer<Utf8>>),
      Pointer<Utf8> Function(Pointer<Pointer<Utf8>>)>(
    'ycash_yecshell_notes',
  );

  late final _serverInfo = _lib.lookupFunction<
      Pointer<Utf8> Function(Pointer<Pointer<Utf8>>),
      Pointer<Utf8> Function(Pointer<Pointer<Utf8>>)>(
    'ycash_yecshell_server_info',
  );

  late final _lastPanic = _lib.lookupFunction<
      Pointer<Utf8> Function(Pointer<Pointer<Utf8>>),
      Pointer<Utf8> Function(Pointer<Pointer<Utf8>>)>(
    'ycash_yecshell_last_panic',
  );

  late final _clearPanic = _lib.lookupFunction<Uint8 Function(), int Function()>(
    'ycash_yecshell_clear_panic',
  );

  late final _syncStart = _lib.lookupFunction<
      Uint8 Function(Pointer<Pointer<Utf8>>),
      int Function(Pointer<Pointer<Utf8>>)>(
    'ycash_yecshell_sync_start',
  );

  late final _syncStartBatch = _lib.lookupFunction<
      Uint8 Function(Uint64, Uint32, Pointer<Pointer<Utf8>>),
      int Function(int, int, Pointer<Pointer<Utf8>>)>(
    'ycash_yecshell_sync_start_batch',
  );

  late final _syncStatus = _lib.lookupFunction<
      Pointer<Utf8> Function(Pointer<Pointer<Utf8>>),
      Pointer<Utf8> Function(Pointer<Pointer<Utf8>>)>(
    'ycash_yecshell_sync_status',
  );

  late final _heightForTimestamp = _lib.lookupFunction<
      Uint64 Function(Uint64, Pointer<Pointer<Utf8>>),
      int Function(int, Pointer<Pointer<Utf8>>)>(
    'ycash_yecshell_height_for_timestamp',
  );

  late final _rescanFromHeight = _lib.lookupFunction<
      Uint8 Function(Uint64, Pointer<Pointer<Utf8>>),
      int Function(int, Pointer<Pointer<Utf8>>)>(
    'ycash_yecshell_rescan_from_height',
  );

  late final _planSend = _lib.lookupFunction<
      Pointer<Utf8> Function(Pointer<Utf8>, Uint64, Pointer<Utf8>, Pointer<Pointer<Utf8>>),
      Pointer<Utf8> Function(Pointer<Utf8>, int, Pointer<Utf8>, Pointer<Pointer<Utf8>>)>(
    'ycash_yecshell_plan_send',
  );

  late final _planShield = _lib.lookupFunction<
      Pointer<Utf8> Function(Uint64, Pointer<Pointer<Utf8>>),
      Pointer<Utf8> Function(int, Pointer<Pointer<Utf8>>)>(
    'ycash_yecshell_plan_shield',
  );

  late final _planUnshield = _lib.lookupFunction<
      Pointer<Utf8> Function(Uint64, Pointer<Pointer<Utf8>>),
      Pointer<Utf8> Function(int, Pointer<Pointer<Utf8>>)>(
    'ycash_yecshell_plan_unshield',
  );

  late final _broadcastPlan = _lib.lookupFunction<
      Pointer<Utf8> Function(Pointer<Utf8>, Pointer<Pointer<Utf8>>),
      Pointer<Utf8> Function(Pointer<Utf8>, Pointer<Pointer<Utf8>>)>(
    'ycash_yecshell_broadcast_plan',
  );

  late final _wipeYec = _lib.lookupFunction<Uint8 Function(), int Function()>(
    'ycash_yecshell_wipe',
  );

  late final _save = _lib.lookupFunction<
      Uint8 Function(Pointer<Pointer<Utf8>>),
      int Function(Pointer<Pointer<Utf8>>)>(
    'ycash_yecshell_save',
  );

  late final _serverHeightForTimestamp = _lib.lookupFunction<
      Uint64 Function(Uint64, Pointer<Pointer<Utf8>>),
      int Function(int, Pointer<Pointer<Utf8>>)>(
    'ycash_yecshell_server_height_for_timestamp',
  );

  late final _legacyCreate = _lib.lookupFunction<
      Uint8 Function(Pointer<Pointer<Utf8>>),
      int Function(Pointer<Pointer<Utf8>>)>(
    'ycash_wallet_create',
  );

  late final _legacyRestore = _lib.lookupFunction<
      Uint8 Function(Pointer<Utf8>, Pointer<Pointer<Utf8>>),
      int Function(Pointer<Utf8>, Pointer<Pointer<Utf8>>)>(
    'ycash_wallet_restore',
  );

  late final _legacyExport = _lib.lookupFunction<
      Pointer<Utf8> Function(Pointer<Pointer<Utf8>>),
      Pointer<Utf8> Function(Pointer<Pointer<Utf8>>)>(
    'ycash_wallet_export_mnemonic',
  );

  late final _legacyWipe = _lib.lookupFunction<Void Function(), void Function()>(
    'ycash_wallet_wipe',
  );

  Pointer<Pointer<Utf8>> _errorPtr() => calloc<Pointer<Utf8>>();

  Never _throw(Pointer<Pointer<Utf8>> error, String fallback) {
    final p = error.value;
    String? message;
    if (p != nullptr) {
      message = p.toDartString();
      _free(p);
    }
    throw YcashCoreException(message ?? fallback);
  }

  String _take(Pointer<Utf8> p) {
    try {
      return p.toDartString();
    } finally {
      _yecFree(p);
    }
  }

  String _takeLegacy(Pointer<Utf8> p) {
    try {
      return p.toDartString();
    } finally {
      _free(p);
    }
  }

  dynamic _takeJson(Pointer<Utf8> p, Pointer<Pointer<Utf8>> error, String fallback) {
    if (p == nullptr) _throw(error, fallback);
    final text = _take(p);
    return jsonDecode(text);
  }

  /// Generates a fresh 24-word Ycash seed without creating or opening any
  /// legacy wallet file.
  String generateMnemonic() {
    final error = _errorPtr();
    try {
      final p = _generateMnemonic(error);
      if (p == nullptr) _throw(error, 'wallet seed generation failed');
      return _take(p);
    } finally {
      calloc.free(error);
    }
  }

  void configure({required String server, required String dataDir}) {
    final error = _errorPtr();
    final s = server.toNativeUtf8();
    final d = dataDir.toNativeUtf8();
    try {
      if (_configure(s, d, error) == 0) _throw(error, 'Ycash engine configuration failed');
    } finally {
      calloc.free(s);
      calloc.free(d);
      calloc.free(error);
    }
  }

  /// Pass as [openYecWallet]'s `birthday` for a genuinely brand-new wallet
  /// (a freshly generated seed that could not possibly have received funds
  /// before this moment) -- the native layer resolves this down to the
  /// current chain tip at creation time instead of scanning from the Ycash
  /// fork height the way a restore of unknown age does. Not used for
  /// restoring a typed-in seed phrase or for routine reopen-on-unlock,
  /// where the actual first-use date is unknown and could be much earlier.
  static const int newWalletBirthday = 0x7FFFFFFFFFFFFFFF;

  void openYecWallet(String seedPhrase, {int birthday = 0}) {
    final error = _errorPtr();
    final seed = seedPhrase.toNativeUtf8();
    try {
      if (_open(seed, birthday, error) == 0) _throw(error, 'Ycash wallet open failed');
    } finally {
      calloc.free(seed);
      calloc.free(error);
    }
  }

  Map<String, dynamic> addresses() {
    final error = _errorPtr();
    try {
      return Map<String, dynamic>.from(_takeJson(_addresses(error), error, 'address lookup failed'));
    } finally {
      calloc.free(error);
    }
  }

  Map<String, dynamic> balances() {
    final error = _errorPtr();
    try {
      return Map<String, dynamic>.from(_takeJson(_balances(error), error, 'balance lookup failed'));
    } finally {
      calloc.free(error);
    }
  }

  List<dynamic> history() {
    final error = _errorPtr();
    try {
      return List<dynamic>.from(_takeJson(_history(error), error, 'transaction history lookup failed'));
    } finally {
      calloc.free(error);
    }
  }

  /// Every note and UTXO the wallet holds, as the engine records them.
  /// Used to compare recorded UTXO values and scripts against the chain.
  /// Server identity and consensus parameters, including the branch id that
  /// transactions are signed with.
  /// The last native panic recorded before the process died, or empty.
  /// Survives the crash because the hook writes it to disk before aborting.
  String lastPanic() {
    final error = _errorPtr();
    try {
      final p = _lastPanic(error);
      if (p == nullptr) return '';
      final s = p.toDartString();
      return s;
    } finally {
      calloc.free(error);
    }
  }

  void clearPanic() => _clearPanic();

  Map<String, dynamic> serverInfo() {
    final error = _errorPtr();
    try {
      return Map<String, dynamic>.from(
        _takeJson(_serverInfo(error), error, 'server info lookup failed'));
    } finally {
      calloc.free(error);
    }
  }

  Map<String, dynamic> notes() {
    final error = _errorPtr();
    try {
      return Map<String, dynamic>.from(_takeJson(_notes(error), error, 'note lookup failed'));
    } finally {
      calloc.free(error);
    }
  }

  void startSync() {
    final error = _errorPtr();
    try {
      if (_syncStart(error) == 0) _throw(error, 'Ycash sync could not start');
    } finally {
      calloc.free(error);
    }
  }

  /// Starts the custom native batch scanner. Larger batches reduce network
  /// round-trip overhead; [workers] controls parallel CPU trial-decryption
  /// workers. Pass 0 for automatic worker selection.
  void startBatchSync({int batchSize = 2000, int workers = 0}) {
    if (batchSize < 100 || batchSize > 15000) {
      throw ArgumentError.value(batchSize, 'batchSize', 'must be 100..15000');
    }
    if (workers < 0 || workers > 32) {
      throw ArgumentError.value(workers, 'workers', 'must be 0..32');
    }
    final error = _errorPtr();
    try {
      if (_syncStartBatch(batchSize, workers, error) == 0) {
        _throw(error, 'Ycash batch scanner could not start');
      }
    } finally {
      calloc.free(error);
    }
  }

  Map<String, dynamic> syncStatus() {
    final error = _errorPtr();
    try {
      return Map<String, dynamic>.from(_takeJson(_syncStatus(error), error, 'sync status lookup failed'));
    } finally {
      calloc.free(error);
    }
  }

  /// Binary-searches the connected lightwalletd server for the height of
  /// the last block at or before [unixSeconds]. This is a handful of
  /// network round trips (not a full sync) so it's safe to call and wait
  /// on before asking the user to confirm a rescan.
  int heightForTimestamp(int unixSeconds) {
    final error = _errorPtr();
    try {
      final height = _heightForTimestamp(unixSeconds, error);
      if (height == 0 && error.value != nullptr) _throw(error, 'could not estimate a block height for that date');
      return height;
    } finally {
      calloc.free(error);
    }
  }

  /// Starts a rescan from [height] on a native background thread. Existing
  /// transaction history is discarded and rebuilt as blocks from [height]
  /// forward are rescanned; poll [syncStatus] the same way as after
  /// [startSync] to watch progress.
  void rescanFromHeight(int height) {
    final error = _errorPtr();
    try {
      if (_rescanFromHeight(height, error) == 0) _throw(error, 'Ycash rescan could not start');
    } finally {
      calloc.free(error);
    }
  }

  Map<String, dynamic> planSend({required String to, required int amount, String? memo}) {
    final error = _errorPtr();
    final a = to.toNativeUtf8();
    final m = (memo ?? '').toNativeUtf8();
    try {
      return Map<String, dynamic>.from(_takeJson(
        _planSend(a, amount, m, error), error, 'send planning failed'));
    } finally {
      calloc.free(a);
      calloc.free(m);
      calloc.free(error);
    }
  }

  Map<String, dynamic> planShield({int amount = 0}) {
    final error = _errorPtr();
    try {
      return Map<String, dynamic>.from(_takeJson(_planShield(amount, error), error, 'shield planning failed'));
    } finally {
      calloc.free(error);
    }
  }

  Map<String, dynamic> planUnshield({int amount = 0}) {
    final error = _errorPtr();
    try {
      return Map<String, dynamic>.from(_takeJson(_planUnshield(amount, error), error, 'unshield planning failed'));
    } finally {
      calloc.free(error);
    }
  }

  String broadcastPlan(Map<String, dynamic> plan) {
    final error = _errorPtr();
    final p = jsonEncode(plan).toNativeUtf8();
    try {
      final result = _broadcastPlan(p, error);
      if (result == nullptr) _throw(error, 'transaction broadcast failed');
      return _take(result);
    } finally {
      calloc.free(p);
      calloc.free(error);
    }
  }

  /// Writes the wallet to disk immediately. Safe to call at any time; throws
  /// only if no wallet is open or the write itself failed.
  void save() {
    final error = _errorPtr();
    try {
      if (_save(error) == 0) _throw(error, 'Ycash wallet save failed');
    } finally {
      calloc.free(error);
    }
  }

  /// Resolves a Unix timestamp (seconds) to a block height using only the
  /// server set by [configure] -- no open wallet required, so this can be
  /// used to pick a wallet's birthday *before* opening it.
  int serverHeightForTimestamp(int unixSeconds) {
    final error = _errorPtr();
    try {
      final height = _serverHeightForTimestamp(unixSeconds, error);
      if (height == 0 && error.value != nullptr) {
        _throw(error, 'could not estimate a block height for that date');
      }
      return height;
    } finally {
      calloc.free(error);
    }
  }

  void wipeYecWallet() {
    if (_wipeYec() == 0) throw const YcashCoreException('Ycash wallet wipe failed');
  }

  // Retained for compatibility with older app code/tests.
  void createWallet() {
    final error = _errorPtr();
    try {
      if (_legacyCreate(error) == 0) _throw(error, 'wallet creation failed');
    } finally { calloc.free(error); }
  }

  void restoreWallet(String phrase) {
    final error = _errorPtr();
    final nativePhrase = phrase.toNativeUtf8();
    try {
      if (_legacyRestore(nativePhrase, error) == 0) _throw(error, 'wallet restore failed');
    } finally {
      calloc.free(nativePhrase);
      calloc.free(error);
    }
  }

  String exportMnemonic() {
    final error = _errorPtr();
    try {
      final result = _legacyExport(error);
      if (result == nullptr) _throw(error, 'mnemonic export failed');
      return _takeLegacy(result);
    } finally {
      calloc.free(error);
    }
  }

  void wipeWallet() => _legacyWipe();
}
