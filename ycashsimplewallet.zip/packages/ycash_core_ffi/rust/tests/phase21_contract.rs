use ycash_core::integration::phase20_lock::{all_pins, SAPLING_CRYPTO_YCASH};
use ycash_core::sapling::vectors::vector_contract_complete;
use ycash_core::sync::validation::ValidationReport;

#[test]
fn upstream_lock_has_three_ycash_targets() {
    assert_eq!(all_pins().len(), 3);
    assert_eq!(SAPLING_CRYPTO_YCASH.name, "sapling-crypto-ycash");
    assert_eq!(SAPLING_CRYPTO_YCASH.revision.len(), 40);
}

#[test]
fn phase21_vector_contract_is_present() {
    assert!(vector_contract_complete());
}

#[test]
fn read_only_validation_never_enables_spending() {
    let report = ValidationReport {
        backend_pinned: true,
        key_vector: true,
        address_vector: true,
        trial_decryption: true,
        note_detection: true,
        nullifier_detection: true,
        balance_accounting: true,
    };
    assert!(report.read_only_ready());
    assert!(!report.spending_ready());
}
