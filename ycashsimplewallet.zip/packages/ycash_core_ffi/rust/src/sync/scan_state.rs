use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct ScannedNote {
    pub note_id: String,
    pub account_id: i64,
    pub value: u64,
    pub height: u32,
    pub spent: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct ObservedNullifier {
    pub nullifier: String,
    pub height: u32,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct WalletScanState {
    pub scanned_height: u32,
    pub notes: Vec<ScannedNote>,
    pub nullifiers: Vec<ObservedNullifier>,
}

impl WalletScanState {
    pub fn apply_note(&mut self, note: ScannedNote) {
        if let Some(existing) = self.notes.iter_mut().find(|n| n.note_id == note.note_id) {
            *existing = note;
        } else {
            self.notes.push(note);
        }
    }

    pub fn apply_nullifier(&mut self, observed: ObservedNullifier) {
        if self.nullifiers.iter().any(|n| n.nullifier == observed.nullifier) { return; }
        self.nullifiers.push(observed);
    }

    pub fn mark_spent_by_nullifier_map(&mut self, owned_note_ids: &[(&str, &str)]) {
        for (note_id, nullifier) in owned_note_ids {
            if self.nullifiers.iter().any(|n| n.nullifier == *nullifier) {
                if let Some(note) = self.notes.iter_mut().find(|n| n.note_id == *note_id) {
                    note.spent = true;
                }
            }
        }
    }

    pub fn confirmed_balance(&self, account_id: i64) -> u64 {
        self.notes.iter()
            .filter(|n| n.account_id == account_id && !n.spent)
            .map(|n| n.value)
            .sum()
    }

    pub fn rewind_to(&mut self, height: u32) {
        self.notes.retain(|n| n.height <= height);
        self.nullifiers.retain(|n| n.height <= height);
        self.scanned_height = height;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn balance_and_rewind_are_deterministic() {
        let mut s = WalletScanState::default();
        s.apply_note(ScannedNote { note_id: "n1".into(), account_id: 0, value: 10, height: 100, spent: false });
        s.apply_note(ScannedNote { note_id: "n2".into(), account_id: 0, value: 25, height: 110, spent: false });
        assert_eq!(s.confirmed_balance(0), 35);
        s.rewind_to(100);
        assert_eq!(s.confirmed_balance(0), 10);
    }
}
