//! Read-only Ycash sync orchestration.
//!
//! Network transport is separated from wallet scanning so that compact-block
//! fetching can be tested without exposing spending keys.  The V3 scheduler
//! keeps several ranges in flight at once and returns them in chain order.
use crate::sync::scanner::{ScanProgress, ScanRange};
use std::sync::Arc;

/// Conservative V3 defaults.  These are intentionally bounded so a fast
/// endpoint cannot cause unbounded memory growth on mobile devices.
pub const V3_BATCH_SIZE: u32 = 2_000;
pub const V3_MAX_IN_FLIGHT: usize = 8;

#[derive(Debug, Clone)]
pub struct ReadOnlySyncPlan {
    pub birthday_height: u32,
    pub batch_size: u32,
    pub max_in_flight: usize,
}

impl Default for ReadOnlySyncPlan {
    fn default() -> Self {
        Self {
            birthday_height: 570_000,
            batch_size: V3_BATCH_SIZE,
            max_in_flight: V3_MAX_IN_FLIGHT,
        }
    }
}

impl ReadOnlySyncPlan {
    pub fn next_range(&self, current: u32, tip: u32) -> Option<ScanRange> {
        if current >= tip { return None; }
        let start = current.saturating_add(1);
        let end = start.saturating_add(self.batch_size.saturating_sub(1)).min(tip);
        Some(ScanRange { start, end })
    }

    pub fn progress(&self, current: u32, tip: u32, notes: u64, spends: u64) -> ScanProgress {
        ScanProgress { height: current, target_height: tip, discovered_notes: notes, discovered_spends: spends }
    }

    /// Number of blocks that can be kept resident by the bounded fetch queue.
    pub fn buffered_blocks(&self) -> usize {
        self.batch_size as usize * self.max_in_flight.max(1)
    }
}

/// Fetches multiple compact-block ranges concurrently while preserving the
/// caller's ordering.  This is the transport half of the V3 pipeline:
/// download workers can stay busy while the caller scans the previous batch.
///
/// The source must be safe for concurrent use. Concrete gRPC clients should
/// use a cheap clone of their channel/client per worker rather than sharing a
/// mutable client behind a lock; this avoids turning concurrency back into a
/// serialized queue.
pub async fn fetch_parallel<S>(
    source_factory: impl Fn() -> S + Send + Sync + 'static,
    ranges: Vec<ScanRange>,
) -> Vec<Result<(ScanRange, Vec<Vec<u8>>), String>>
where
    S: crate::lightwallet::grpc::CompactBlockSource + Send + 'static,
    S::Error: Send + std::fmt::Display + 'static,
{
    let factory = Arc::new(source_factory);
    let mut tasks = Vec::with_capacity(ranges.len());

    for range in ranges {
        let factory = Arc::clone(&factory);
        tasks.push(tokio::spawn(async move {
            let mut source = factory();
            source
                .compact_blocks(range.start as u64, range.end as u64)
                .map(|blocks| (range, blocks))
                .map_err(|e| e.to_string())
        }));
    }

    let mut out = Vec::with_capacity(tasks.len());
    for task in tasks {
        match task.await {
            Ok(result) => out.push(result),
            Err(e) => out.push(Err(format!("fetch worker failed: {e}"))),
        }
    }
    out.sort_by_key(|r| r.as_ref().map(|(range, _)| range.start).unwrap_or(u32::MAX));
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn v3_defaults_are_bounded() {
        let p = ReadOnlySyncPlan::default();
        assert_eq!(p.batch_size, 2_000);
        assert_eq!(p.max_in_flight, 8);
        assert_eq!(p.buffered_blocks(), 16_000);
    }

    #[test]
    fn next_range_is_contiguous_and_bounded() {
        let p = ReadOnlySyncPlan::default();
        assert_eq!(p.next_range(100, 2_099).unwrap().start, 101);
        assert_eq!(p.next_range(100, 2_099).unwrap().end, 2_099);
        assert!(p.next_range(2_099, 2_099).is_none());
    }
}
