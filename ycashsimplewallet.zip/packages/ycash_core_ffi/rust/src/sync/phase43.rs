//! Phase 43: compact-block stream -> authenticated storage integration.
//!
//! Transport and cryptographic trial decryption remain separated: a concrete Ycash
//! backend implements `CompactBlockDecoder`; this module enforces continuity,
//! fail-closed decoding, and atomic persistence through the Phase 42 boundary.

use rusqlite::Connection;
use crate::sync::phase42::{apply_scan_batch, ScanBatch, ScannedSaplingNote, Phase42Error};

#[derive(Debug, Clone)]
pub struct CompactBlockEnvelope {
    pub height: u32,
    pub block_hash: [u8; 32],
    pub prev_hash: [u8; 32],
    pub encoded: Vec<u8>,
}

#[derive(Debug, Clone, Default)]
pub struct DecodedCompactBlock {
    pub notes: Vec<ScannedSaplingNote>,
    pub spent_nullifiers: Vec<String>,
}

/// Implemented only by a pinned Ycash-compatible compact-block scanner.
/// It must perform trial decryption and commitment-tree authentication itself;
/// callers cannot inject unauthenticated notes into Phase 42 storage.
pub trait CompactBlockDecoder {
    type Error: std::fmt::Display;
    fn decode_authenticated(&mut self, block: &CompactBlockEnvelope)
        -> Result<DecodedCompactBlock, Self::Error>;
}

#[derive(Debug, Clone, Default)]
pub struct ChainCursor {
    pub height: Option<u32>,
    pub hash: Option<[u8; 32]>,
}

#[derive(Debug, thiserror::Error)]
pub enum Phase43Error {
    #[error("non-contiguous compact block height: expected {expected}, got {got}")]
    HeightGap { expected: u32, got: u32 },
    #[error("compact block previous hash does not match chain cursor")]
    PrevHashMismatch,
    #[error("scanner rejected compact block: {0}")]
    Decode(String),
    #[error("storage rejected authenticated scan batch: {0}")]
    Storage(String),
}

/// Applies one real compact block. Chain continuity is checked before scanner output
/// is persisted, and scan state advances atomically only after successful ingestion.
pub fn process_compact_block<D: CompactBlockDecoder>(
    conn: &mut Connection,
    cursor: &mut ChainCursor,
    decoder: &mut D,
    block: CompactBlockEnvelope,
) -> Result<(), Phase43Error> {
    if let Some(h) = cursor.height {
        let expected = h.checked_add(1).ok_or(Phase43Error::HeightGap { expected: u32::MAX, got: block.height })?;
        if block.height != expected {
            return Err(Phase43Error::HeightGap { expected, got: block.height });
        }
        if cursor.hash != Some(block.prev_hash) {
            return Err(Phase43Error::PrevHashMismatch);
        }
    }

    let decoded = decoder.decode_authenticated(&block)
        .map_err(|e| Phase43Error::Decode(e.to_string()))?;
    let batch = ScanBatch {
        scanned_height: block.height,
        notes: decoded.notes,
        spent_nullifiers: decoded.spent_nullifiers.into_iter().map(|n| (n, block.height)).collect(),
    };
    apply_scan_batch(conn, &batch).map_err(|e: Phase42Error| Phase43Error::Storage(e.to_string()))?;
    cursor.height = Some(block.height);
    cursor.hash = Some(block.block_hash);
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    struct Reject;
    impl CompactBlockDecoder for Reject {
        type Error = &'static str;
        fn decode_authenticated(&mut self, _: &CompactBlockEnvelope) -> Result<DecodedCompactBlock, Self::Error> { Err("no scanner") }
    }
    #[test]
    fn rejects_decoder_failure_without_advancing_cursor() {
        let mut conn = Connection::open_in_memory().unwrap();
        let mut cursor = ChainCursor::default();
        let mut d = Reject;
        let b = CompactBlockEnvelope { height: 1, block_hash:[1;32], prev_hash:[0;32], encoded:vec![] };
        assert!(process_compact_block(&mut conn, &mut cursor, &mut d, b).is_err());
        assert!(cursor.height.is_none());
    }
}
