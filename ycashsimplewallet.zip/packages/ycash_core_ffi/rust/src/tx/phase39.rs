//! Phase 39: source-verified Sapling transaction builder integration.
//!
//! This module binds the wallet transaction boundary to the exact vendored
//! `zcash_primitives` builder API. It intentionally accepts already-decoded
//! Sapling types; decoding wallet database bytes and resolving vault handles
//! remain separate responsibilities so secrets never cross the FFI boundary.

use super::{SpendContext, TransactionPlan};

#[derive(Debug, thiserror::Error)]
pub enum Phase39Error {
    #[error("Phase 38 validation failed: {0}")]
    Phase38(#[from] super::phase38::Phase38Error),
    #[error("no authenticated Sapling spends were supplied")]
    NoSpends,
    #[error("transaction feature is not enabled")]
    TransactionFeatureDisabled,
}

/// Final wallet-side validation before constructing an upstream transaction.
/// Cryptographic construction is deliberately unavailable unless the exact
/// vendored transaction feature is selected at compile time.
pub fn validate_for_builder(
    plan: &TransactionPlan,
    context: &SpendContext,
) -> Result<(), Phase39Error> {
    super::phase38::validate_for_transaction_layer(plan, context)?;
    if context.selected_notes.is_empty() {
        return Err(Phase39Error::NoSpends);
    }
    if !super::phase38::YCAST_TRANSACTION_STACK_SELECTED {
        return Err(Phase39Error::TransactionFeatureDisabled);
    }
    Ok(())
}

#[cfg(feature = "ycash-transaction")]
pub mod upstream {
    //! Exact Phase 39 upstream integration surface.
    //!
    //! The concrete calls are intentionally typed against the vendored crates:
    //! `Builder::new`, `add_sapling_spend`, `add_sapling_output`, and `build`.
    //! This prevents hand-written transaction serialization.

    pub use zcash_primitives_ycash::transaction::builder::{BuildConfig, Builder};
    pub use zcash_proofs_ycash::prover::LocalTxProver;

    /// Compile-time assertion that the selected upstream API exposes the real
    /// transaction builder type used by Phase 39.
    pub fn builder_type_is_linked<P: zcash_primitives_ycash::consensus::Parameters>(
        params: P,
        target_height: zcash_primitives_ycash::consensus::BlockHeight,
        config: BuildConfig,
    ) -> Builder<'static, P, ()> {
        Builder::new(params, target_height, config)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn empty_context_is_rejected_before_builder() {
        let plan = TransactionPlan {
            recipient: "ys1example".to_string(),
            amount: 1,
            memo: None,
        };
        let context = SpendContext {
            network: super::super::YcashNetwork::Regtest,
            selected_notes: vec![],
            change_address: "ys1change".to_string(),
            proving_params: super::super::ProvingParameters {
                spend_params_path: "spend.params".to_string(),
                output_params_path: "output.params".to_string(),
            },
        };
        assert!(matches!(validate_for_builder(&plan, &context), Err(Phase39Error::Phase38(_)) | Err(Phase39Error::NoSpends) | Err(Phase39Error::TransactionFeatureDisabled)));
    }
}
