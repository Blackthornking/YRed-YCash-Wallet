//! Phase 20: exact upstream identity and feature gate.

#[derive(Debug, Clone, Copy)]
pub struct PinnedUpstream {
    pub name: &'static str,
    pub repository: &'static str,
    pub revision: &'static str,
}

pub const SAPLING_CRYPTO_YCASH: PinnedUpstream = PinnedUpstream {
    name: "sapling-crypto-ycash",
    repository: "https://github.com/ycashfoundation/sapling-crypto-ycash",
    revision: "c5e596c239dbf9138a74246b843bcd01413f51c7",
};

pub const LIBRUSTZCASH_NU61: PinnedUpstream = PinnedUpstream {
    name: "librustzcash-nu61",
    repository: "https://github.com/ycashfoundation/librustzcash-nu61",
    revision: "26de676f2c5c0e2d35e0b28b7bea704f4ff0411e",
};

pub const ZCASH_SYNC_YCASH: PinnedUpstream = PinnedUpstream {
    name: "zcash-sync",
    repository: "https://github.com/ycashfoundation/zcash-sync",
    revision: "d91b60309b9b414ad5359ae3da4407b8abe234df",
};

pub fn all_pins() -> [PinnedUpstream; 3] {
    [SAPLING_CRYPTO_YCASH, LIBRUSTZCASH_NU61, ZCASH_SYNC_YCASH]
}

/// This feature only proves that the exact Sapling crate is present in the build.
/// It does NOT authorize spending; deterministic Ycash vectors still gate that.
#[cfg(feature = "ycash-sapling")]
pub fn sapling_backend_compiled() -> bool {
    let _ = core::any::TypeId::of::<sapling_crypto_ycash::value::NoteValue>();
    true
}

#[cfg(not(feature = "ycash-sapling"))]
pub fn sapling_backend_compiled() -> bool { false }
