//! Phase 19 backend selection and safety gate.
//!
//! This module intentionally distinguishes *source availability* from
//! *cryptographic compatibility*. A backend can only be promoted after
//! deterministic Ycash vectors are supplied and passed.

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BackendState {
    ReferenceOnly,
    VectorValidated,
    ProductionApproved,
}

#[derive(Debug, Clone)]
pub struct BackendManifest {
    pub name: &'static str,
    pub state: BackendState,
    pub sapling_only: bool,
    pub orchard_enabled: bool,
}

pub const YCASH_BACKEND: BackendManifest = BackendManifest {
    name: "Ycash Sapling backend",
    state: BackendState::ReferenceOnly,
    sapling_only: true,
    orchard_enabled: false,
};

pub fn spending_enabled() -> bool {
    matches!(YCASH_BACKEND.state, BackendState::ProductionApproved)
        && YCASH_BACKEND.sapling_only
        && !YCASH_BACKEND.orchard_enabled
}
