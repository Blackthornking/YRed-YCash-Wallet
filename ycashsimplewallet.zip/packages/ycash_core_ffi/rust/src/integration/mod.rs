//! Phase 17 integration manifest.
//!
//! This module deliberately does not embed a floating upstream git dependency.
//! Production builds must pin reviewed Ycash-compatible revisions and record
//! their commit IDs in `YCASH_UPSTREAM_LOCK.toml`.

#[derive(Debug, Clone)]
pub struct UpstreamLock {
    pub name: &'static str,
    pub repository: &'static str,
    pub revision: &'static str,
}

pub const REQUIRED_UPSTREAMS: &[UpstreamLock] = &[
    UpstreamLock {
        name: "ycash sapling crypto",
        repository: "https://github.com/ycashfoundation/sapling-crypto-ycash",
        revision: "c5e596c239dbf9138a74246b843bcd01413f51c7",
    },
    UpstreamLock {
        name: "ycash librustzcash nu61",
        repository: "https://github.com/ycashfoundation/librustzcash-nu61",
        revision: "26de676f2c5c0e2d35e0b28b7bea704f4ff0411e",
    },
    UpstreamLock {
        name: "ycash sync reference",
        repository: "https://github.com/ycashfoundation/zcash-sync",
        revision: "d91b60309b9b414ad5359ae3da4407b8abe234df",
    },
];

pub fn production_ready() -> bool {
    REQUIRED_UPSTREAMS.iter().all(|u| u.revision != "PIN_BEFORE_PRODUCTION")
}
pub mod phase18_gate;
pub mod phase19_backend;

pub mod phase20_lock;
