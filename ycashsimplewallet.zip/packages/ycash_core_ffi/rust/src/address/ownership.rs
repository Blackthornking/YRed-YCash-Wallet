//! Address ownership results used by the sync layer.

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum AddressOwnership {
    Owned,
    WatchOnly,
    External,
    Unknown,
}

#[derive(Debug, Clone)]
pub struct DerivedAddress {
    pub address: String,
    pub account: u32,
    pub index: u32,
    pub ownership: AddressOwnership,
}
