//! Lightwallet transport boundary.
//!
//! `src/lightwallet/grpc.rs` existed on disk but the `lightwallet` module was
//! never declared in `lib.rs`, and the directory had no `mod.rs` -- so the file
//! was simply not part of the crate. Nothing referenced it until
//! `sync::read_only::fetch_parallel` started bounding its type parameter on
//! `crate::lightwallet::grpc::CompactBlockSource`, which then failed to
//! resolve (E0433: cannot find `lightwallet` in the crate root).
//!
//! This module root, plus the matching `pub mod lightwallet;` in `lib.rs`,
//! brings the existing file into the crate. Nothing in it changes.

pub mod grpc;
