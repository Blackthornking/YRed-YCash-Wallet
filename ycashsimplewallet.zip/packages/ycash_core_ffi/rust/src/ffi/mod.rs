//! C ABI for the Flutter/Dart host.
//!
//! The ABI intentionally exposes only wallet lifecycle operations that are
//! implemented and tested in this crate. Transaction signing and address
//! derivation remain unavailable until Ycash compatibility vectors pass.

use crate::network::YcashMainnet;
use crate::wallet::WalletEngine;
use std::ffi::{CStr, CString};
use std::os::raw::c_char;
use std::ptr;
use std::sync::{Mutex, OnceLock};
use zeroize::{Zeroize, Zeroizing};

struct WalletState {
    mnemonic: Option<Zeroizing<String>>,
}

static STATE: OnceLock<Mutex<WalletState>> = OnceLock::new();

fn state() -> &'static Mutex<WalletState> {
    STATE.get_or_init(|| Mutex::new(WalletState { mnemonic: None }))
}

fn c_string(value: impl AsRef<str>) -> *mut c_char {
    CString::new(value.as_ref()).unwrap_or_else(|_| CString::new("internal string error").unwrap()).into_raw()
}

fn error_out(error: *mut *mut c_char, message: impl AsRef<str>) {
    if !error.is_null() {
        unsafe { *error = c_string(message); }
    }
}

#[no_mangle]
pub extern "C" fn ycash_engine_version() -> *mut c_char {
    c_string(crate::ENGINE_VERSION)
}

/// Returns a JSON capability manifest. This is informational and must not be
/// treated as permission to enable spending.
#[no_mangle]
pub extern "C" fn ycash_backend_status_json() -> *mut c_char {
    match serde_json::to_string(&crate::backend::status::current()) {
        Ok(json) => c_string(json),
        Err(_) => c_string("{\"error\":\"status serialization failed\"}"),
    }
}

#[no_mangle]
pub extern "C" fn ycash_wallet_create(error: *mut *mut c_char) -> u8 {
    let engine = WalletEngine::new(YcashMainnet::config());
    match engine.create_wallet() {
        Ok((mnemonic, _seed)) => match state().lock() {
            Ok(mut guard) => {
                guard.mnemonic = Some(Zeroizing::new(mnemonic.expose_for_backup().to_owned()));
                1
            }
            Err(_) => {
                error_out(error, "wallet state lock failed");
                0
            }
        },
        Err(e) => {
            error_out(error, e.to_string());
            0
        }
    }
}

#[no_mangle]
pub extern "C" fn ycash_wallet_restore(
    phrase: *const c_char,
    error: *mut *mut c_char,
) -> u8 {
    if phrase.is_null() {
        error_out(error, "seed phrase was null");
        return 0;
    }

    let phrase = match unsafe { CStr::from_ptr(phrase) }.to_str() {
        Ok(v) => v,
        Err(_) => {
            error_out(error, "seed phrase was not valid UTF-8");
            return 0;
        }
    };

    let engine = WalletEngine::new(YcashMainnet::config());
    match engine.restore_wallet(phrase, "") {
        Ok((mnemonic, _seed)) => match state().lock() {
            Ok(mut guard) => {
                guard.mnemonic = Some(Zeroizing::new(mnemonic.expose_for_backup().to_owned()));
                1
            }
            Err(_) => {
                error_out(error, "wallet state lock failed");
                0
            }
        },
        Err(e) => {
            error_out(error, e.to_string());
            0
        }
    }
}

#[no_mangle]
pub extern "C" fn ycash_wallet_export_mnemonic(error: *mut *mut c_char) -> *mut c_char {
    match state().lock() {
        Ok(guard) => match &guard.mnemonic {
            Some(m) => c_string(m.as_str()),
            None => {
                error_out(error, "wallet has not been created or restored");
                ptr::null_mut()
            }
        },
        Err(_) => {
            error_out(error, "wallet state lock failed");
            ptr::null_mut()
        }
    }
}

#[no_mangle]
pub extern "C" fn ycash_wallet_wipe() {
    if let Ok(mut guard) = state().lock() {
        guard.mnemonic = None;
    }
}

/// Derives an Argon2id hash of the wallet password, used both for the
/// local password-verification record and (via [`SeedVault`] on the Dart
/// side) as the key that wraps the seed phrase. Exported as
/// `ycash_password_argon2id` — the app moved from a numeric PIN to a full
/// password, and the symbol name now matches.
#[no_mangle]
pub extern "C" fn ycash_password_argon2id(
    pin: *const c_char,
    salt_b64: *const c_char,
    memory_kib: u32,
    iterations: u32,
    parallelism: u32,
    error: *mut *mut c_char,
) -> *mut c_char {
    use argon2::{Algorithm, Argon2, Params, Version};
    use base64::{engine::general_purpose::URL_SAFE_NO_PAD, Engine as _};

    if pin.is_null() || salt_b64.is_null() {
        error_out(error, "password or salt was null");
        return ptr::null_mut();
    }
    let pin_bytes = unsafe { CStr::from_ptr(pin) }.to_bytes();
    let salt_text = match unsafe { CStr::from_ptr(salt_b64) }.to_str() {
        Ok(v) => v,
        Err(_) => { error_out(error, "salt was not valid UTF-8"); return ptr::null_mut(); }
    };
    let salt = match URL_SAFE_NO_PAD.decode(salt_text) {
        Ok(v) if v.len() >= 16 => v,
        _ => { error_out(error, "invalid Argon2 salt"); return ptr::null_mut(); }
    };
    let params = match Params::new(memory_kib, iterations, parallelism, Some(32)) {
        Ok(v) => v,
        Err(e) => { error_out(error, e.to_string()); return ptr::null_mut(); }
    };
    let argon2 = Argon2::new(Algorithm::Argon2id, Version::V0x13, params);
    let mut out = [0u8; 32];
    if let Err(e) = argon2.hash_password_into(pin_bytes, &salt, &mut out) {
        error_out(error, e.to_string());
        return ptr::null_mut();
    }
    let encoded = URL_SAFE_NO_PAD.encode(out);
    out.zeroize();
    c_string(encoded)
}


/// Returns the wallet's verified shielded address.
///
/// Phase 57 exposes the ABI boundary now, but it deliberately fails closed until
/// the pinned Ycash Sapling implementation is linked and deterministic vectors pass.
#[no_mangle]
pub extern "C" fn ycash_wallet_shielded_address(error: *mut *mut c_char) -> *mut c_char {
    match state().lock() {
        Ok(guard) => match &guard.mnemonic {
            Some(m) => match crate::read_only::shielded_address(m.as_str()) {
                Ok(address) => c_string(address),
                Err(e) => { error_out(error, e.to_string()); ptr::null_mut() }
            },
            None => { error_out(error, "wallet has not been created or restored"); ptr::null_mut() }
        },
        Err(_) => { error_out(error, "wallet state lock failed"); ptr::null_mut() }
    }
}

#[no_mangle]
pub extern "C" fn ycash_wallet_transparent_address(error: *mut *mut c_char) -> *mut c_char {
    match state().lock() {
        Ok(guard) => match &guard.mnemonic {
            Some(m) => match crate::read_only::transparent_address(m.as_str()) {
                Ok(address) => c_string(address),
                Err(e) => { error_out(error, e.to_string()); ptr::null_mut() }
            },
            None => { error_out(error, "wallet has not been created or restored"); ptr::null_mut() }
        },
        Err(_) => { error_out(error, "wallet state lock failed"); ptr::null_mut() }
    }
}

#[no_mangle]
pub extern "C" fn ycash_read_only_capabilities_json() -> *mut c_char {
    // These remain false until CI proves the complete native path.
    c_string(r#"{\"ycash_verified\":false,\"shielded_address\":false,\"transparent_address\":false,\"sync\":false,\"balances\":false,\"history\":false,\"phase\":57}"#)
}

#[no_mangle]
pub extern "C" fn ycash_string_free(value: *mut c_char) {
    if !value.is_null() {
        unsafe { drop(CString::from_raw(value)); }
    }
}
