//! Phase 18 upstream boundary.
//!
//! This module deliberately prevents accidental use of generic Zcash network
//! parameters. Every cryptographic backend must explicitly prove that it is
//! configured for Ycash before the engine will advertise a capability.

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BackendCapability {
    KeyDerivation,
    SaplingAddress,
    TrialDecrypt,
    NoteDetection,
    Spend,
}

#[derive(Debug, Clone)]
pub struct BackendIdentity {
    pub name: &'static str,
    pub source_sha256: &'static str,
    pub ycash_verified: bool,
}

pub trait SaplingBackend: Send + Sync {
    fn identity(&self) -> BackendIdentity;
    fn supports(&self, capability: BackendCapability) -> bool;
}

pub fn require_ycash_verified<B: SaplingBackend>(backend: &B) -> anyhow::Result<()> {
    let id = backend.identity();
    anyhow::ensure!(id.ycash_verified, "backend {} is not Ycash-verified", id.name);
    Ok(())
}
