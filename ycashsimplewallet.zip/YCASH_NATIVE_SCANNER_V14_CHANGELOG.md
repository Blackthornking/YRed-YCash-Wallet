# Ycash Native Cryptographic Scanner V14

## Scanner core replacement

The previous `LightWallet::scan_block_internal` entry point has been removed from the production scan path and replaced by `ycash_native_scanner::scan_block_native`.

### Design

- Ycash-specific scanner orchestration is isolated in `lightwallet/ycash_native_scanner.rs`.
- All compact Sapling outputs are collected before wallet-state mutation.
- Trial decryption uses the existing pinned Ycash Sapling cryptographic implementation and persistent prepared-IVK cache.
- Cryptographic work is separated from the ordered commitment-tree/witness commit phase.
- Shielded-spend matching remains constant-time at the nullifier comparison layer.
- Wallet transaction construction, note construction, tree updates, reorg handling, and serialization remain compatible with the existing wallet state.
- The old scanner function is no longer called by the production sync path.

## Safety boundary

This is an architectural replacement, not a change to Ycash consensus or Sapling cryptographic rules. No speculative Bridge Skip or ProofSkip path is enabled by this change.

## Validation

The build environment for this artifact did not contain `cargo`/`rustc`, so a local compilation could not be performed in this session. The source was checked for stale production references to `scan_block_internal`; only historical test comments remain.
