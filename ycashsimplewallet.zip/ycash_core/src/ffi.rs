use libc::{c_char, c_uchar};
use std::ffi::CString;

fn set_error(out: *mut *mut c_char, msg: &str) {
    unsafe {
        if !out.is_null() {
            *out = CString::new(msg).unwrap_or_else(|_| CString::new("native error").unwrap()).into_raw();
        }
    }
}

#[unsafe(no_mangle)]
pub extern "C" fn ycash_string_free(s: *mut c_char) {
    if !s.is_null() {
        unsafe { drop(CString::from_raw(s)); }
    }
}

/// Native backend capability probe.
///
/// This confirms that the crate was built with the YCash Sapling feature. It
/// deliberately does not claim that a transaction can be signed until the
/// concrete builder path has completed all required inputs.
#[unsafe(no_mangle)]
pub extern "C" fn ycash_sapling_backend_available(_error: *mut *mut c_char) -> u8 {
    #[cfg(feature = "ycash-sapling")]
    {
        let _ = core::mem::size_of::<sapling::Node>();
        1
    }

    #[cfg(not(feature = "ycash-sapling"))]
    {
        set_error(_error, "ycash_core was built without the ycash-sapling feature");
        0
    }
}

/// Validates fixed-width secret inputs at the native boundary before any
/// upstream signing call. Secret buffers remain native and are zeroized.
#[unsafe(no_mangle)]
pub extern "C" fn ycash_sapling_spend_signing_ready(
    ask: *const c_uchar,
    ar: *const c_uchar,
    sighash: *const c_uchar,
    error: *mut *mut c_char,
) -> u8 {
    if ask.is_null() || ar.is_null() || sighash.is_null() {
        set_error(error, "null Sapling signing input");
        return 0;
    }
    // The actual signature is produced only after a complete transaction
    // builder supplies the consensus-correct sighash.
    set_error(error, "transaction builder integration required before spend signing");
    0
}
