//! Phase 52: transaction-construction integration boundary.
//!
//! This module deliberately delegates proving, signing and serialization to the
//! vendored YCash-compatible librustzcash/Sapling code. It does not implement
//! cryptographic primitives itself.

use core::fmt;

/// A validated transaction request crossing the Flutter -> Rust boundary.
/// Secret material is represented by an opaque native handle, never by a Dart string.
#[derive(Debug, Clone)]
pub struct TransactionRequest {
    pub target_height: u32,
    pub recipient: String,
    pub amount: u64,
    pub fee: u64,
    pub memo: Option<Vec<u8>>,
    pub spending_key_handle: u64,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum BuildError {
    InvalidAmount,
    InvalidFee,
    MissingRecipient,
    MissingNativeKey,
    WrongNetwork,
    MissingWitness,
    Upstream(String),
}

impl fmt::Display for BuildError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::InvalidAmount => write!(f, "amount must be non-zero"),
            Self::InvalidFee => write!(f, "fee is invalid"),
            Self::MissingRecipient => write!(f, "recipient is missing"),
            Self::MissingNativeKey => write!(f, "native spending key is unavailable"),
            Self::WrongNetwork => write!(f, "recipient or request belongs to the wrong YCash network"),
            Self::MissingWitness => write!(f, "authenticated Sapling witness is required"),
            Self::Upstream(e) => write!(f, "upstream builder failed: {e}"),
        }
    }
}

/// Result returned only after the upstream builder has produced a transaction.
#[derive(Debug, Clone)]
pub struct BuiltTransaction {
    pub tx_bytes: Vec<u8>,
    pub txid: [u8; 32],
}

/// Native transaction-builder interface.
///
/// The concrete implementation must obtain authenticated notes/witnesses from
/// synchronized wallet state and invoke the vendored upstream builder. This keeps
/// Sapling proving and spend authorization signatures inside audited Rust code.
pub trait UpstreamTransactionBuilder {
    fn build(&mut self, request: &TransactionRequest) -> Result<BuiltTransaction, BuildError>;
}

pub fn validate_request(request: &TransactionRequest) -> Result<(), BuildError> {
    if request.amount == 0 { return Err(BuildError::InvalidAmount); }
    if request.recipient.trim().is_empty() { return Err(BuildError::MissingRecipient); }
    if request.spending_key_handle == 0 { return Err(BuildError::MissingNativeKey); }
    Ok(())
}
