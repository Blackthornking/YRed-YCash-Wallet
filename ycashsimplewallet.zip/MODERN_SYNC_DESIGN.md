# Modern Ycash Sync Design

Pipeline:

lightwalletd -> bounded compact-block range -> batched Sapling trial decryption -> ordered wallet commit

Principles:
1. Ycash-only parameters, no coin-switch branches.
2. No old wallet database migration.
3. One persistent sync round/connection.
4. Bounded batch memory.
5. Parallel CPU trial decryption with fixed worker budget.
6. Height validation before scanning.
7. Ordered commit after scanning.
8. Single-flight sync start.
9. Explicit sync error state so a failed run cannot leave the UI permanently stuck.
10. Future adaptive batch sizing can be added after profiling.

Initial mobile profile: 512 blocks / 4 workers.


## AWBS layer

The existing native batch scanner is now wrapped by Ycash Adaptive Batch Warp Scanner (AWBS). The scanner itself remains unchanged; AWBS adapts the next compact-block batch from measured device/network performance, starting at 2,000 blocks and staying between 500 and 4,000 blocks. Ordered wallet commits, one-batch prefetch, retry/reorg handling and wallet serialization remain unchanged.
