# AWBS V3

## Goal
Move the V2 Ycash Adaptive Batch Warp Scanner toward YWallet-class throughput by keeping network fetch, native scanning, and wallet persistence continuously busy while preserving wallet ordering and protocol behavior.

## Changes
- Raised AWBS hard maximum from 4,000 to 10,000 blocks.
- Kept 2,000 blocks as the default starting batch.
- Added bounded prefetch depth of 3 ranges instead of 1.
- Prefetch ranges use the existing shared gRPC connection and existing scanner.
- Adaptive controller remains feedback-driven; it only changes the *next* range.
- Increased the slow-batch threshold to 8 seconds to avoid shrinking healthy large batches too aggressively.
- Kept the existing native crypto scanner and worker pool intact.
- Kept ordered wallet commits and reorg invalidation semantics intact.
- Kept the 1,140-byte signature format and verification behavior untouched (sync changes do not alter transaction/signature serialization).

## Important
10,000 is a maximum batch size / engineering target, not a guarantee of 10,000 blocks/s. End-to-end throughput remains constrained by lightwalletd, device CPU, memory bandwidth, protobuf decoding, cryptographic scanning, transparent transaction lookups, and SQLite persistence.

## Benchmark path
1. Start at 2,000.
2. Measure complete batch throughput.
3. AWBS increases toward 2,500 -> 3,125 -> 3,906 -> 4,882 -> 6,102 -> 7,627 -> 9,533 -> 10,000 while batches remain below the fast threshold.
4. If a batch exceeds the slow threshold, AWBS backs off by 25%.
5. Use pprof / Android profiling to identify the remaining end-to-end bottleneck.


## V3 transaction-ID RPC correction
- Corrected the transparent-address RPC to the canonical lightwalletd method `GetTaddressTxids`.
- The previous vendored yecshell protobuf used the legacy `GetAddressTxids` name; this could fail against Ycash servers exposing the canonical method.
- The returned `RawTransaction.data` continues to be parsed as the full transaction and passed through the existing wallet `scan_full_tx` path, so transaction IDs are derived by the wallet's existing transaction parser rather than trusting an address-specific response field.
- No wallet serialization or transaction-ID representation was changed.

## V3 throughput pipeline update — 2026-09-12

- Increased the default compact-block batch from 1,000 to 2,000.
- Added a bounded V3 transport scheduler with up to 8 concurrent batch fetches.
- Added `ReadOnlySyncPlan::buffered_blocks()` to make queue capacity explicit.
- Added ordered `fetch_parallel()` orchestration so concurrently fetched ranges are returned in chain order.
- Kept the existing cryptographic scanner, transaction-ID handling, signature/serialization behavior, and authenticated storage boundary unchanged.
- Build/test could not be executed in this environment because the Rust toolchain (`cargo`) is not installed; the source package is provided for local CI/build validation.
