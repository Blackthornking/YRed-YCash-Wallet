import 'config.dart';

/// One entry from the native `do_list_transactions` output.
///
/// The native side emits a flat JSON list where direction is encoded only in
/// the sign of `amount`, and a transparent receive carries an `address` that
/// starts with `s1` while a shielded one starts with `ys1`. Parsing that into
/// a typed object once, here, keeps the guesswork out of the widgets.
class WalletTx {
  final String txid;
  final int blockHeight;
  final DateTime time;

  /// Zatoshi. Negative for sends, positive for receives.
  final int amount;

  /// Counterparty address when the native side reports one. Absent on some
  /// shielded sends, where the recipient lives in `outgoing_metadata`.
  final String? address;
  final String? memo;

  const WalletTx({
    required this.txid,
    required this.blockHeight,
    required this.time,
    required this.amount,
    this.address,
    this.memo,
  });

  bool get incoming => amount >= 0;

  /// Block height 0 means the transaction is known but not yet mined, so it
  /// is in the mempool rather than confirmed.
  bool get pending => blockHeight <= 0;

  /// Transparent transactions are the ones whose details are publicly visible
  /// on a block explorer; shielded ones are not, which is why the detail
  /// screen offers the explorer link only for these.
  bool get transparent => (address ?? '').startsWith('s1') || (address ?? '').startsWith('s3');

  bool get shielded => (address ?? '').startsWith('ys1');

  double get yec => amount / 1e8;

  int confirmations(int chainTip) {
    if (pending || chainTip <= 0 || blockHeight > chainTip) return 0;
    return chainTip - blockHeight + 1;
  }

  String get explorerUrl => YcashConfig.txUrl(txid);

  static WalletTx? fromJson(dynamic raw) {
    if (raw is! Map) return null;
    final txid = raw['txid']?.toString();
    if (txid == null || txid.isEmpty) return null;

    final amount = (raw['amount'] as num?)?.toInt() ?? 0;
    final height = (raw['block_height'] as num?)?.toInt() ?? 0;
    final seconds = (raw['datetime'] as num?)?.toInt() ?? 0;

    // A shielded send records its recipient under outgoing_metadata rather
    // than a top-level address, so fall back to the first entry there.
    String? address = raw['address']?.toString();
    String? memo = raw['memo']?.toString();
    final outgoing = raw['outgoing_metadata'];
    if (outgoing is List && outgoing.isNotEmpty && outgoing.first is Map) {
      final first = outgoing.first as Map;
      address ??= first['address']?.toString();
      memo ??= first['memo']?.toString();
    }
    if (address != null && address.isEmpty) address = null;
    if (memo != null && memo.trim().isEmpty) memo = null;

    return WalletTx(
      txid: txid,
      blockHeight: height,
      time: DateTime.fromMillisecondsSinceEpoch(seconds * 1000),
      amount: amount,
      address: address,
      memo: memo,
    );
  }

  static List<WalletTx> parseAll(List<dynamic> raw) {
    final list = raw.map(fromJson).whereType<WalletTx>().toList();
    // Newest first. Pending entries have height 0, so sort by time and let
    // them float to the top where they belong.
    list.sort((a, b) {
      if (a.pending != b.pending) return a.pending ? -1 : 1;
      return b.time.compareTo(a.time);
    });
    return list;
  }
}
