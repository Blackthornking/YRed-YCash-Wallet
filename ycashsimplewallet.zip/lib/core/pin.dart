import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// A 6-digit PIN, stored as a salted iterated hash.
///
/// The PIN is never written anywhere in the clear. Six digits is only a
/// million combinations, so a single round of SHA-256 would fall to an offline
/// search in seconds if the secure store ever leaked; iterating makes each
/// guess cost something. That is a speed bump, not real key strength — the
/// actual protection is that this lives in Android's hardware-backed keystore
/// and that repeated wrong guesses are throttled below.
///
/// This is deliberately a second factor, not a replacement for biometrics.
/// Biometrics alone unlock the app; the PIN is additionally required for the
/// two actions that can lose you the wallet: revealing the recovery phrase and
/// wiping the device's copy of it.
class WalletPin {
  static const _hashKey = 'ycash.simple.pinHash';
  static const _saltKey = 'ycash.simple.pinSalt';
  static const _failKey = 'ycash.simple.pinFails';
  static const _untilKey = 'ycash.simple.pinLockedUntil';

  static const length = 6;

  /// Wrong guesses allowed before a wait is imposed.
  static const _freeAttempts = 5;

  static const _iterations = 60000;

  static const _storage = FlutterSecureStorage();

  static Future<bool> isSet() async =>
      (await _storage.read(key: _hashKey))?.isNotEmpty == true;

  static String _hash(String pin, String salt) {
    // Chained SHA-256. Each round feeds the previous digest back in, so the
    // work cannot be parallelised within a single guess.
    // Explicitly List<int>: utf8.encode returns Uint8List on current Dart,
    // while Digest.bytes returns List<int>, so an inferred `var` locks the
    // variable to Uint8List and the reassignment below fails to compile.
    List<int> digest = utf8.encode('$salt|$pin');
    for (var i = 0; i < _iterations; i++) {
      digest = sha256.convert(digest).bytes;
    }
    return base64Encode(digest);
  }

  static bool isValidFormat(String pin) =>
      pin.length == length && RegExp(r'^\d{6}$').hasMatch(pin);

  static Future<void> setPin(String pin) async {
    if (!isValidFormat(pin)) {
      throw ArgumentError('PIN must be exactly $length digits');
    }
    final rnd = Random.secure();
    final salt = base64Encode(List<int>.generate(16, (_) => rnd.nextInt(256)));
    await _storage.write(key: _saltKey, value: salt);
    await _storage.write(key: _hashKey, value: _hash(pin, salt));
    await _clearFailures();
  }

  static Future<void> clear() async {
    await _storage.delete(key: _hashKey);
    await _storage.delete(key: _saltKey);
    await _clearFailures();
  }

  /// Seconds remaining before another attempt is allowed, or 0.
  static Future<int> lockoutRemaining() async {
    final raw = await _storage.read(key: _untilKey);
    final until = int.tryParse(raw ?? '') ?? 0;
    final now = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    return until > now ? until - now : 0;
  }

  static Future<void> _clearFailures() async {
    await _storage.delete(key: _failKey);
    await _storage.delete(key: _untilKey);
  }

  static Future<void> _recordFailure() async {
    final fails = (int.tryParse(await _storage.read(key: _failKey) ?? '') ?? 0) + 1;
    await _storage.write(key: _failKey, value: '$fails');
    if (fails > _freeAttempts) {
      // Back off steeply but cap it, so a forgotten PIN doesn't turn into an
      // unusable app: 30s, 60s, 120s ... up to 15 minutes.
      final steps = fails - _freeAttempts;
      final wait = min(900, 30 * (1 << (steps - 1).clamp(0, 6)));
      final until = DateTime.now().millisecondsSinceEpoch ~/ 1000 + wait;
      await _storage.write(key: _untilKey, value: '$until');
    }
  }

  /// Returns true when [pin] matches. Throttled after repeated failures.
  static Future<bool> verify(String pin) async {
    if (await lockoutRemaining() > 0) return false;
    final salt = await _storage.read(key: _saltKey);
    final stored = await _storage.read(key: _hashKey);
    if (salt == null || stored == null) return false;
    final ok = _hash(pin, salt) == stored;
    if (ok) {
      await _clearFailures();
    } else {
      await _recordFailure();
    }
    return ok;
  }
}
