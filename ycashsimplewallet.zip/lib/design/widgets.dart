import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'tokens.dart';

/// Shared polish primitives (Phase 11).
///
/// Before this file existed, screens each invented their own bare
/// `Text('Error: $e')` or left a `CircularProgressIndicator()` spinning
/// forever with no way out. Every screen should reach for these instead
/// of hand-rolling error/empty/busy UI, so the app behaves consistently
/// when something goes wrong.

/// A retry-capable error state. Use this any time a screen's primary
/// content failed to load and the user needs a way to try again rather
/// than being stuck looking at a spinner or a dead end.
class YErrorState extends StatelessWidget {
  final String message;
  final VoidCallback? onRetry;
  final String retryLabel;
  final IconData icon;

  const YErrorState({
    super.key,
    required this.message,
    this.onRetry,
    this.retryLabel = 'Retry',
    this.icon = Icons.error_outline,
  });

  @override
  Widget build(BuildContext context) {
    // liveRegion: true so screen readers announce the failure as soon as
    // it replaces a loading state, instead of the user having to
    // stumble onto silent, unannounced text.
    return Semantics(
      liveRegion: true,
      label: 'Error: $message',
      child: Padding(
        padding: const EdgeInsets.all(YSpacing.lg),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: YColors.danger, size: 40),
            const SizedBox(height: YSpacing.md),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(color: YColors.textSecondary),
            ),
            if (onRetry != null) ...[
              const SizedBox(height: YSpacing.lg),
              OutlinedButton.icon(
                onPressed: onRetry,
                icon: const Icon(Icons.refresh),
                label: Text(retryLabel),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

/// A "nothing here yet" state — no data, but not an error. Distinct from
/// [YErrorState] so users can tell "empty" from "broken" at a glance.
class YEmptyState extends StatelessWidget {
  final String title;
  final String? subtitle;
  final IconData icon;

  const YEmptyState({
    super.key,
    required this.title,
    this.subtitle,
    this.icon = Icons.inbox_outlined,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(YSpacing.lg),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: YColors.textMuted, size: 40),
          const SizedBox(height: YSpacing.md),
          Text(
            title,
            textAlign: TextAlign.center,
            style: const TextStyle(
                color: YColors.textPrimary, fontWeight: FontWeight.w600),
          ),
          if (subtitle != null) ...[
            const SizedBox(height: YSpacing.xs),
            Text(
              subtitle!,
              textAlign: TextAlign.center,
              style: const TextStyle(color: YColors.textMuted, fontSize: 13),
            ),
          ],
        ],
      ),
    );
  }
}

/// A busy/loading state with an optional label. Prefer this over a bare
/// [CircularProgressIndicator] anywhere the wait could plausibly be long
/// enough that the user might wonder what's happening (wallet creation,
/// a plan being fetched over the network, etc).
class YBusyState extends StatelessWidget {
  final String? label;
  const YBusyState({super.key, this.label});

  @override
  Widget build(BuildContext context) {
    return Semantics(
      liveRegion: true,
      label: label ?? 'Loading',
      child: Padding(
        padding: const EdgeInsets.all(YSpacing.lg),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const CircularProgressIndicator(color: YColors.shieldedPrimary),
            if (label != null) ...[
              const SizedBox(height: YSpacing.md),
              Text(label!, style: const TextStyle(color: YColors.textSecondary)),
            ],
          ],
        ),
      ),
    );
  }
}

/// Fade+slide entrance motion that respects the OS "reduce motion"
/// accessibility setting. Under that setting this renders [child]
/// immediately with no animation at all — shortening the animation isn't
/// enough, since reduce-motion users are opting out of motion, not just
/// asking for it to be quick.
class YEnter extends StatelessWidget {
  final Widget child;
  final Duration delay;

  const YEnter({super.key, required this.child, this.delay = Duration.zero});

  /// Convenience for staggering a list: each item's delay is
  /// `index * step`.
  factory YEnter.staggered({
    Key? key,
    required Widget child,
    required int index,
    Duration step = const Duration(milliseconds: 60),
  }) =>
      YEnter(key: key, delay: step * index, child: child);

  @override
  Widget build(BuildContext context) {
    if (MediaQuery.of(context).disableAnimations) return child;
    return child
        .animate(delay: delay)
        .fadeIn(duration: YMotion.base, curve: YMotion.standard)
        .slideY(
            begin: 0.05, end: 0, duration: YMotion.base, curve: YMotion.standard);
  }
}

/// Named haptic taps so call sites document *why* they're buzzing
/// instead of sprinkling raw [HapticFeedback] calls with no context.
class YHaptics {
  YHaptics._();

  static void acknowledge() => HapticFeedback.lightImpact();
  static void warn() => HapticFeedback.heavyImpact();
  static void selection() => HapticFeedback.selectionClick();
}
