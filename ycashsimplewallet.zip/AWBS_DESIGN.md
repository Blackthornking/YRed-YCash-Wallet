# Ycash Adaptive Batch Warp Scanner (AWBS)

This build integrates the scanner already present in `ycashwalletone` and puts
an adaptive controller around it in `ycashsimplewallet`.

## What is preserved

- The existing native `ycash_batch_scan` implementation is retained unchanged.
- Sapling trial-decryption remains parallelized through the existing worker pool.
- Compact blocks are fetched through the existing shared gRPC connection.
- Blocks are committed to the wallet in strict chain order.
- Reorg detection and retry behavior remain in the existing scanner path.
- The wallet serialization, addresses, balances, transaction format and network
  protocol are not changed.

## AWBS controller

AWBS measures each completed batch on the actual device, including compact-block
receive, native scanning and the transparent-address tail.

- Starting batch: **2,000 blocks** (the current wallet setting).
- Minimum adaptive batch: **500**.
- Maximum adaptive batch: **4,000**.
- If a batch completes in under ~2 seconds, the next batch grows by 25%.
- If it takes over ~6 seconds, the next batch shrinks by 25%.
- Otherwise the current size is retained.
- The size is clamped to the safe 500..4,000 range.

The controller only changes the *next* request after the current batch has
fully completed. It never changes the order of wallet commits.

## Why this is the right layer

The scanner is the expensive cryptographic engine. AWBS does not duplicate or
replace it. It controls how much work is handed to that scanner at once,
allowing fast devices/network paths to amortize RPC overhead while preventing
slow phones from accumulating oversized compact-block buffers.

## Current pipeline

`lightwalletd -> shared gRPC connection -> bounded AWBS batch -> existing native
batch scanner -> ordered wallet commit -> transparent transaction scan -> next
AWBS batch`

The existing prefetch depth remains one batch to keep peak memory bounded on
Android.

## Validation required on-device

The build environment here does not contain a Rust toolchain, so the native
crate cannot be compiled in this environment. Before shipping, run:

1. `cargo fmt --check` / project formatter.
2. Android release/debug build.
3. New-wallet sync from the current server tree state.
4. Existing-wallet resume after interruption/backgrounding.
5. 2,000-block starting batch and observe AWBS growth/shrink in logs.
6. Reorg/retry test.
7. Balance/history/address regression tests.
8. Send/signing regression with Sapling parameters installed.

No signature or wallet serialization changes are introduced by AWBS.

## V8 tuning ceiling
AWBS V8 supports a bounded batch ladder of 1,000, 2,000, 4,000, 6,000, 8,000, 10,000, 12,000 and 15,000 compact blocks. The 15,000 value is a ceiling, not a throughput guarantee. Prefetch depth is reduced as batches grow to keep total buffered compact blocks bounded.
