# AWBS V9 — Scanner Speed Pipeline

This revision focuses on reducing fixed CPU overhead in the shielded-output scanner without changing wallet serialization, transaction ordering, commitment-tree semantics, or signature/verification behavior.

## Implemented

- Persistent prepared-IVK cache across scanned blocks.
  - Prepared Sapling IVKs are now retained in a non-serialized cache.
  - The cache is automatically rebuilt if the wallet's IVK set changes.
  - Worker tasks share the prepared cache through `Arc` instead of cloning the prepared key tables.
- Adaptive crypto tiles.
  - Default: 512 outputs/tile.
  - Default: 1024 outputs/tile for blocks with 4096+ outputs.
  - `YCASH_CRYPTO_CHUNK_SIZE` can benchmark 128..2048.
  - `YCASH_MAX_CRYPTO_CHUNKS` can benchmark 2..32 concurrent tiles.
- Fixed a stale hard-coded tile-size increment so the adaptive tile size controls the complete scheduling loop.
- Retained bounded in-flight work to avoid creating an unbounded queue on large 15,000-block batches.
- Existing ordered wallet/tree commit path is unchanged.
- Existing HTTP/2 compact-block prefetch remains enabled, so the next network range can transfer while the current range is scanned.

## Correctness/compatibility

- No wire-format changes.
- No wallet serialization changes.
- No transaction ordering changes.
- No commitment-tree or witness ordering changes.
- No cryptographic verification rule changes.
- The persistent IVK cache is runtime-only and is not serialized.

## Benchmarking

The Rust/Flutter toolchains are not installed in the supplied build environment, so this package must be compiled and benchmarked on a development machine/device.

Suggested benchmark matrix:

- `YCASH_CRYPTO_CHUNK_SIZE=256,512,1024,1536`
- `YCASH_MAX_CRYPTO_CHUNKS=4,8,12,16`

Measure end-to-end blocks/sec, CPU time, allocations, battery/thermal behaviour, and scan correctness. Do not claim a blocks/sec target until it is measured on the target Android device.

## V10 — Height Checkpoint Index

- Added `awbs_sync.sqlite` alongside the wallet data.
- Durable sync checkpoint is advanced every **500 committed blocks**.
- The wallet file is persisted before the SQLite checkpoint is advanced.
- A 30-second fallback save remains for slow sync/network conditions.
- Final sync saves also update the checkpoint.
- Manual save and rescan completion update the checkpoint.
- The wallet file remains authoritative; the SQLite index is a recovery/progress index only.
- No transaction serialization, wallet key format, commitment-tree ordering, or verification semantics were changed.
